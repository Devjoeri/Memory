﻿using System.Windows.Controls;

namespace Memory
{
    public interface INavigator
    {
        void Navigate(Page p);
    }
}